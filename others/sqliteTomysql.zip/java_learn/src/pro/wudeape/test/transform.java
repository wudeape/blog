package pro.wudeape.test;
import java.sql.*;

public class transform {
    // sqllite  连接信息配置
    private static final String Class_Name = "org.sqlite.JDBC";
    // 本地sqlite数据库的位置
    private static final String DB_URL = "jdbc:sqlite:F:\\db_mysqltest.db";

    // mysql的链接信息配置
    // JDBC 驱动名及数据库 URL
    private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String Mysql_DB_URL = "jdbc:mysql://192.168.10.90:3306/test";

    // mysql数据库的用户名与密码，需要根据自己的设置
    private static final String USER = "root";
    private static final String PASS = "123456";

    Connection conn = null;
    PreparedStatement stmt = null;
    ResultSet rs = null;
    Connection sqlConn = null;
    PreparedStatement pstmt = null;

    public void sqliteTomysql() throws SQLException , ClassNotFoundException {

        // sqlite，配置连接
        Class.forName(Class_Name);// 静态方法调用了启动类加载器,确保该类被加载并已连接
        conn = DriverManager.getConnection(DB_URL);
        stmt = conn.prepareStatement("select * from wude");
        rs = stmt.executeQuery();

        // mysql 连接配置
        String sql = "INSERT INTO wude(id,username,password) VALUES(?,?,?)";
        pstmt = mysqlConnect().prepareStatement(sql);

        while (rs.next()) {
            pstmt.setString(1, rs.getString("id"));
            pstmt.setString(2, rs.getString("username"));
            pstmt.setString(3, rs.getString("password"));
            // 使用jdbc 的addBatch 题号效率
            pstmt.addBatch();
        }

        pstmt.executeBatch();// 执行批处理！
        sqlConn.commit();// 执行完后，手动提交事务
        sqlConn.setAutoCommit(true);// 再把自动提交打开

        sqlConn.close();
        conn.close();


    }
    public Connection mysqlConnect()throws SQLException , ClassNotFoundException {
        Class.forName(JDBC_DRIVER);
        sqlConn = DriverManager.getConnection(Mysql_DB_URL,USER,PASS);
        sqlConn.setAutoCommit(false);// 将自动提交关闭
        return sqlConn;

    }

    public static void main(String args[]) {

        transform transform =new transform();
        try{
            transform.sqliteTomysql();
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
        }catch (Exception e){
            e.printStackTrace();
        }

    }

}




