//package pro.wudeape.test;
//
//import java.sql.*;
//
//public class OpSqliteDB {
//
//    // sqllite  连接信息配置
//    private static final String Class_Name = "org.sqlite.JDBC";
//    private static final String DB_URL = "jdbc:sqlite:F:\\db_mysqltest.db";
//
//    // mysql的链接信息配置
//    // JDBC 驱动名及数据库 URL
//    private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
//    private static final String Mysql_DB_URL = "jdbc:mysql://localhost:3306/RUNOOB";
//
//    // mysql数据库的用户名与密码，需要根据自己的设置
//     private static final String USER = "root";
//     private static final String PASS = "root";
//
//
//    public static void main(String args[]) {
//        // load the sqlite-JDBC driver using the current class loader
//        Connection connection = null;
//        Connection mysqlconnection = null;
//        try {
//            connection = createConnection();
//            mysqlconnection = mysqlConnection();
//            func1(connection);
//
//
//            System.out.println("Success!");
//        } catch (SQLException e) {
//            System.err.println(e.getMessage());
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            try {
//                if (connection != null)
//                    connection.close();
//            } catch (SQLException e) {
//                // connection close failed.
//                System.err.println(e);
//            }
//        }
//    }
//    // 创建mysql的链接信息
//
//    // 创建Sqlite数据库连接
//    public static Connection createConnection() throws SQLException, ClassNotFoundException {
//        Class.forName(Class_Name);
//        return DriverManager.getConnection(DB_URL);
//    }
//    public static Connection mysqlConnection() throws  SQLException,ClassNotFoundException{
//        Class.forName(JDBC_DRIVER);
//        return DriverManager.getConnection(Mysql_DB_URL,USER,PASS);
//    }
//
//    public static void func1(Connection connection) throws SQLException {
//        Statement statement = connection.createStatement();
//        Statement statement1 = connection.createStatement();
//        statement.setQueryTimeout(30); // set timeout to 30 sec.
//        // 执行查询语句
//        ResultSet rs = statement.executeQuery("select * from wude");
//        while (rs.next()) {
//            //   直接读取信息
//            String col1 = rs.getString("id");
//            String col2 = rs.getString("username");
//            String col3 = rs.getString("password");
//            System.out.println("col1 = " + col1 + "  col2 = " + col2 + " col3 = " + col3);
//
//            // 执行插入语句操作
////            statement1.executeUpdate("insert into table_name2(col2) values('" + col2_value + "')");
////            // 执行更新语句
////            statement1.executeUpdate("update table_name2 set 字段名1=" +  字段值1 + " where 字段名2='" +  字段值2 + "'");
//
//            // mysql 连接 写入信息
//
//
//        }
//    }
//
//    public  static void insertMysql(){
//
//            Connection conn = null;
//            Statement stmt = null;
//            try{
//                // 注册 JDBC 驱动
//                Class.forName(JDBC_DRIVER);
//
//                // 打开链接
//                System.out.println("连接数据库...");
//                conn = DriverManager.getConnection(Mysql_DB_URL,USER,PASS);
//
//                // 执行查询
//                System.out.println(" 实例化Statement对象...");
//                stmt = conn.createStatement();
//                String sql;
//                sql = "SELECT id, name, url FROM websites";
//                ResultSet rs1 = stmt.executeQuery(sql);
//
//                // 展开结果集数据库
//                while(rs1.next()){
//                    // 通过字段检索
//                    int id  = rs1.getInt("id");
//                    String name = rs1.getString("name");
//                    String url = rs1.getString("url");
//
//                    // 输出数据
//                    System.out.print("ID: " + id);
//                    System.out.print(", 站点名称: " + name);
//                    System.out.print(", 站点 URL: " + url);
//                    System.out.print("\n");
//                }
//                // 完成后关闭
//                rs1.close();
//                stmt.close();
//                conn.close();
//            }catch(SQLException se){
//                // 处理 JDBC 错误
//                se.printStackTrace();
//            }catch(Exception e){
//                // 处理 Class.forName 错误
//                e.printStackTrace();
//            }finally{
//                // 关闭资源
//                try{
//                    if(stmt!=null) stmt.close();
//                }catch(SQLException se2){
//                }// 什么都不做
//                try{
//                    if(conn!=null) conn.close();
//                }catch(SQLException se){
//                    se.printStackTrace();
//                }
//            }
//            System.out.println("Goodbye!");
//        }
//        }
//
//
//
//
//
//
//
//
