//
//  CommentView.h
//  仿造淘宝商品详情页
//
//  Created by yixiang on 16/3/25.
//  Copyright © 2016年 yixiang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YXTabItemBaseView.h"

@interface CommentView : YXTabItemBaseView

@end
