//
//  ViewController.h
//  仿造淘宝商品详情页
//
//  Created by yixiang on 16/3/23.
//  Copyright © 2016年 yixiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

